/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab2;

/**
 *
 * @author asus
 */
public class LinkedSet extends LinkCollection{
        public LinkedSet(){
          super();
        }
        public void add(Object e) {
         if(!super.contains(e)){
           super.add(e);
           }       
        }
        public LinkedSet union(LinkedSet other){
           Object [] uset = other.toArray();
           Object [] usets = this.toArray();
           LinkedSet ass = new LinkedSet();
           for(int i=0;i<other.size();i++){
             ass.add(uset[i]);
             
           }
           for(int i=0;i<this.size();i++){
             ass.add(usets[i]); 
           }
           return ass;
        }
        public LinkedSet intersection(LinkedSet other){
           Object [] inter_set = other.toArray();        
           LinkedSet as = new LinkedSet();
           for(int i=0;i<other.size();i++){
                      if(this.contains(inter_set[i])){
                                 as.add(inter_set[i]);
                      }
           }
           return as;
        }
        public boolean equals(LinkedSet other){
           Object []  set = other.toArray();
           if(this.size() == other.size()){
                      for(int i=0;i<other.size();i++){
                          if(this.contains(set[i])){
                                 return true;
                                 }                         
                      }         
           }
           return false;
        }     
}
