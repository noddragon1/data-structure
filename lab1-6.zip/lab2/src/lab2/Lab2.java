/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab2;

import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author asus
 */
public class Lab2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        LinkedSet nomi_a = new LinkedSet();       
        Scanner input = new Scanner(System.in);
        System.out.println("Nomination A : ");
        String name = "";
        name = input.nextLine();
        while(!name.equals("")){
          nomi_a.add(name);
          name = input.nextLine();
        }
        LinkedSet nomi_b = new LinkedSet();       
        Scanner inputs = new Scanner(System.in);
        System.out.println("Nomination B : ");
        String names = "";
        name = inputs.nextLine();
        while(!names.equals("")){
          nomi_b.add(names);
          names = inputs.nextLine();
        }
        
        System.out.println("Nomination A : ");
        System.out.println(Arrays.toString(nomi_a.toArray()));
        System.out.println("Nomination B : ");
        System.out.println(Arrays.toString(nomi_b.toArray()));

        System.out.println(nomi_a.size() + " names nomination for A");
        System.out.println(nomi_b.size() + " names nomination for B");
        System.out.println(nomi_a.intersection(nomi_b).size() + " names nomination for both A and B"); 
        System.out.println(nomi_a.union(nomi_b).size() + " names nomination for A or B");
        System.out.println(nomi_a.equals(nomi_b));
    }
        
        
}
    

