/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab6;

import java.util.Scanner;

/**
 *
 * @author asus
 */
public class Lab6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        SeparateChainingHashMap h = new SeparateChainingHashMap(10);
        Scanner s =new Scanner(System.in);
        String line = s.nextLine().trim();
        while(!line.equals("/quit")){
            switch(line){
                case "/add","/edit"  : edit(s,h);
                case "/remove"   : remove(s,h);
                case"/print"   : h.printTable();
                case"/list"   : System.out.println("Available commands: /add  /edit  /remove  /print  /quit");
            }
            System.out.print("Enter a command");
            line = s.nextLine().trim();
        }
    }
    
    private static void edit(Scanner s,SeparateChainingHashMap h){
        System.out.print("StudentID: ");
        String sid = s.nextLine().trim();
        System.out.print("CourseID: ");
        String cid = s.nextLine().trim();
        System.out.print("Grade: ");
        String grade = s.nextLine().trim();
        h.put(new StudentCourse(sid,cid),grade);
        h.printTable();
    }
    private static void remove(Scanner s,SeparateChainingHashMap h){
         System.out.print("StudentID: ");
         String sid = s.nextLine().trim();
         System.out.print("CourseID: ");
         String cid = s.nextLine().trim();
         h.remove(new StudentCourse(sid,cid));
         h.printTable();
    }
}
