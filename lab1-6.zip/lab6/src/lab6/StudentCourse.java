/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab6;

/**
 *
 * @author asus
 */
public class StudentCourse {
    private String student_id;
    private String course_id;        
    public StudentCourse(String s,String c){
        student_id = s;
        course_id = c;
    }
    public boolean equals(Object o){//check key
     if(!(o instanceof StudentCourse)){return false;}
     StudentCourse sc = (StudentCourse) o;
     return student_id.equals(sc.student_id)&&course_id.equals(sc.course_id);
    }
    public int hashCode(){
        int n =0;
        String s = student_id+course_id;
        for(int i =0;i<s.length();i++){
            n+= Integer.parseInt(s.substring(i,i+1));
        }
        return n;
    }
    public String toString(){
        return student_id+" "+course_id+" ";
    }
}
