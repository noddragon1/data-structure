/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3;

/**
 *
 * @author asus
 */
public class Graph {
    public ArrayList vertices;
    public Graph(){
       vertices = new ArrayList(0);
    }
    public int size(){
      return vertices.size();
    }
    public void ChangeLabel(String a,String b){
      if(!containVertex(a)){return;}
      Vertex v = getVertex(a);
      v.changeLabel(b);
    }
    public void addVertex(String label){
      if(containVertex(label)){return;}
      vertices.add(new Vertex(label));
    }
    public void addEdge(String vName,String uName){
        if(!containVertex(vName)||!containVertex(uName)){return;}
        Vertex v = getVertex(vName);
        Vertex u = getVertex(uName);
        v.adjList.add(u);    
    }
    private int posOfVertexNamed(String label){
        for(int i = 0;i<vertices.size();i++){
            Vertex v = ((Vertex)vertices.get(i));
            if(v.equals(label)){return i;}
        }
        return -1;
    }
    public boolean containVertex(String label){
        return posOfVertexNamed(label) != -1;  
    }
    private Vertex getVertex(String label){
        int pos = posOfVertexNamed(label);
        if(pos == -1){return null;}
        return((Vertex)vertices.get(pos));   
       
    }
    public boolean adjacent(String a,String b){
        if(!containVertex(a)||!containVertex(b)){return false;}
        Vertex ver1 = getVertex(a);
        Vertex ver2 = getVertex(b);
        return ver1.adjList.contains(ver2)||ver2.adjList.contains(ver1);
    }
    public String toStr(){
        String x = "";
        for(int i = 0;i<vertices.size();i++){
            String y = ((Vertex)vertices.get(i)).label;
            x+=y;
            if(i<vertices.size()-1){x+=",";}
        }
        return "Gragh{"+"vertices="+x+"}";
    }
    private static class Vertex{
        public String label;
        public ArrayList adjList;
        public Vertex(String a){
         label = a;
         adjList = new ArrayList(0);
        }
        public boolean equals(String name){
         return label.equals(name);
        }
        public void changeLabel(String name){
         label = name;
        }
    }  
}
    
