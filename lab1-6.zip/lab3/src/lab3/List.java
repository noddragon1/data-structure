/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3;

/**
 *
 * @author asus
 */
public interface List extends Collection{
    public void add(int i,Object element);
    public void remove(int i);
    public void get(int i);
    public void set(int i,Object element);
}
