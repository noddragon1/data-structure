/*
 * �ç���ҧ������ : ��Ѻ�Ҩ���
 * http://www.cp.eng.chula.ac.th/~somchai/books
 */
package lab5;

import java.util.NoSuchElementException;

/**
 * ���ʷ�����ҧ�Ǥ�´���������
 * @author ����� ����Է���ٵ�С��
 */
public class ArrayQueue implements Queue {
  private Object[] elementData;
  private int size;
  private int front;

  public ArrayQueue(int cap) {
    elementData = new Object[cap];
    size = front = 0;
  }
  public boolean isEmpty() {
    return size == 0;
  }
  public int size() {
    return size;
  }
  public void enqueue(Object e) {
    if (size == elementData.length) {
      Object[] a = new Object[2 * elementData.length];
      for (int i = 0, j = front; i < size;
           i++, j = (j+1)%elementData.length)
        a[i] = elementData[j];
      front = 0; elementData = a;
    }
    int b = (front + size) % elementData.length;
    elementData[b] = e; size++;
  }
  public Object peek() {
    if (isEmpty()) throw new NoSuchElementException();
    return elementData[front];
  }
  public Object dequeue() {
    Object e = peek();
    elementData[front] = null;
    front = (front + 1) % elementData.length;
    int x = 0;
    for (int i = 0; i < this.size; i++) {
            if(elementData[i] != null){
                x++;
            }
        }
    if(x<=(0.25*size)){
    size--;
    }
    return e;
  }
  public Queue split(){
        Queue q1 = new ArrayQueue(this.size);
        Queue q2 = new ArrayQueue((int)this.size/2);
        int f1;
        int f3;
        if(this.size == 0){
            f1 = 0;
            f3 = 0;
        }else {
            f1 = (int)this.size/4;
            f3 = (int)this.size*3/4;
            System.out.println(f1);
            System.out.println(f3);
            for (int i = 0 ; i < this.size; i++) {
                if(i<=f1-1){
                    q1.enqueue(elementData[i]);
                }else if (f1-1<i && i<=f3-1){
                    q2.enqueue(elementData[i]);
                }else {
                    q1.enqueue(elementData[i]);
                }
            }
        }
        return q2;
    }
  public Queue merge(ArrayQueue a){
        ArrayQueue q = new ArrayQueue(a.size+this.size);
        for (int i = 0; i < this.size ; i++) {
            q.enqueue(elementData[i]);
        }
        for (int i = 0; i < a.size ; i++) {
            q.enqueue(a.elementData[i]);
        }

        return q;
    } 
  public ArrayQueue clear(){
        int s = this.size;
        for (int i = 0; i < s ; i++) {
            if(elementData[i] != null){
                this.dequeue();
            }
        }
        return this;
    }
  public ArrayQueue reverse(){
        String[] x = new String[this.size];
        ArrayQueue q = new ArrayQueue(this.size);
        for (int i = 0 ; i<this.size ; i++) {
            x[i] = (String)this.elementData[i];
        }
        for (int i = x.length-1 ; i >= 0; i--) {
            q.enqueue(x[i]);
        }

        return q;
    }
  public String toString(){
        String t = "";
        for(int i=0 ;i<elementData.length;i++){
            t += elementData[i] + " ";
        }
        return t;
    }
}

