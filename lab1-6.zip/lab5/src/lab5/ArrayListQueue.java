/*
 * �ç���ҧ������ : ��Ѻ�Ҩ���
 
 */
package lab5;

import java.util.NoSuchElementException;

/**
 * ���ʷ�����ҧ�Ǥ�´��� ArrayList
 * @author ����� ����Է���ٵ�С��
 */
public class ArrayListQueue implements Queue {
  private List list;
  public ArrayListQueue(int cap) {
    list = new ArrayList(cap);
  }
  public boolean isEmpty() {return list.isEmpty();}
  public int size() {return list.size();}
  public void enqueue(Object e) {list.add(e);}
  public Object peek() {
    if (isEmpty()) throw new NoSuchElementException();
    return list.get(0);
  }
  public Object dequeue() {
    Object e = peek();
    list.remove(0);
    return e;
  }
 public Queue split(){

        int x = (int)(list.size()/2);
        int front = (int)(x*.25);
        int last = (int)(list.size()-(x*.25));

        List keep = front==0 ? new ArrayList(2) : new ArrayList(front*2);

        for(int i=0;i<=front;i++)
            keep.add(list.get(i));

        for(int i=last;i<list.size();i++)
            keep.add(list.get(i));

        Queue q = new ArrayListQueue(list.size()-2*front);

        for(int i=front;i<last;i++)
            q.enqueue(list.get(i));

        list=keep;
        return q;

    }

    public ArrayListQueue merge(ArrayListQueue a){

        ArrayListQueue q = new ArrayListQueue(a.list.size()+list.size());

        for(int i=0;i<list.size();i++){
            q.enqueue(list.get(i));
        }

        for(int i=0;i<a.list.size();i++){
            q.enqueue(a.list.get(i));
        }
        return q;

    }

    public void clear(){
        for(int i=0;i<list.size();i++){
            list.remove(i);
        }
    }

    public void reverse(){
        List re = new ArrayList(list.size());
        for(int i=list.size()-1;i>=0;i--){
            re.add(i);
        }
    }
}

