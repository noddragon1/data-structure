/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab5;

/**
 *
 * @author asus
 */
public class Lab5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       ArrayQueue a = new ArrayQueue(4);
	a.enqueue("1");
	a.enqueue("2");
	a.enqueue("3");
	a.enqueue("5");
	ArrayQueue b = new ArrayQueue(4);
	b.enqueue("3");
	b.enqueue("4");
	b.enqueue("7");
	ArrayQueue c = new ArrayQueue(1);
	//System.out.println(a.merge(b).toString());
	//System.out.println(a.split().toString());
	//System.out.println(b.clear().size());
	//System.out.println(b.reverse().toString());
    }
    
}
