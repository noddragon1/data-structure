/*
 * 2301263 Semester 1 2563
 * LAB 4 14 September 2563
 */
package lab4;

/**
 *
 * @author Jaruloj
 */
public interface Stack {
  public boolean isEmpty();  // is stack empty?
  public int size();         // get the size of stack
  public void push(Object e);// add e on top of stack
  public Object pop();       // get and remove the topmost value in stack
  public Object peek();      // get the topmost value in stack
}
