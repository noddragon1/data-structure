/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4;


import java.util.ArrayList;
/**
 *
 * @author asus
 */
public class Postfix{
    private String[] token; 
   
    public Postfix(String postfixStr){
      token = postfixStr.split(" ");
    }
    private Boolean isOp(String x){
        String i = "+-*/^";
        return i.contains(x);
    }
    private float apply(float a, float b,String op){
      float num = 0;
      if(op.equals("+")){return num = a+b;}
      if(op.equals("-")){return num = a-b;}
      if(op.equals("*")){return num = a*b;}
      if(op.equals("/")){return num = a/b;}
      if(op.equals("^")){return num = (float) Math.pow(a,b);}
      return num;
    }
    public float eval(){
        Stack s = new ArrayStack();
        for(int i =0 ; i<token.length ; i++){
            if(isOp(token[i])){ //chk ว่าเป็น Operator มั้ย ถ้าเป็น Operator 8ือ if(True) จะทำงานในนี้
                float a = Float.parseFloat(s.pop().toString());
                float b = Float.parseFloat(s.pop().toString());
                float c = apply(b,a,token[i]);
                s.push(c);
            }
            else s.push(token[i]);
        }
        float ans = Float.parseFloat(s.pop().toString());
        
        return ans;
    }
    public String toInfix(){
        Stack s = new ArrayStack();
        for(int i =0 ; i<token.length ; i++){
            if(isOp(token[i])){
                String a = (String) s.pop();
                String b = (String) s.pop();
                String c ="(" + b + token[i] + a + ")";
                s.push(c);
            }
            else s.push(token[i]);
        }
        String inf = (String) s.pop();
       
       
        return inf;
    }
    
}
