/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4;

import java.util.Scanner;

/**
 *
 * @author asus
 */
public class Lab4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner input = new Scanner(System.in);
        System.out.print("Enter Postfix Expression: " );
            String in = input.nextLine();
            Postfix pf = new Postfix(in);
          // System.out.println(pf.isOp("+"));
            System.out.println("Eval Result: " +pf.eval());
            System.out.println("Infix Expression: " + pf.toInfix());
    }
    
}
