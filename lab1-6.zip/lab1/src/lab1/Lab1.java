/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab1;

import java.util.Arrays;

/**
 *
 * @author asus
 */
public class Lab1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       ArraySet a = new ArraySet(3);
       ArraySet b = new ArraySet(2);
       a.add(1);
       a.add(2);
       a.add(3);
       b.add(1);
       b.add(4);
       b.add(2);
       System.out.println(Arrays.toString(a.toArray()));
       System.out.println(Arrays.toString(b.toArray()));
       System.out.println(Arrays.toString((a.union(b)).toArray()));
       System.out.println(Arrays.toString((a.intersection(b)).toArray()));
       System.out.println(a.equals(b));
    }
    
}
